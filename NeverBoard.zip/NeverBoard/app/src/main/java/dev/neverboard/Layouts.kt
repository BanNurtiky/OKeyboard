package dev.neverboard

enum class KeyType { CHAR, SHIFT, BACKSPACE, SYMBOLS, LETTERS, PAGE, GLOBE, COMMA, PERIOD, SPACE, ACTION }

enum class Page { LETTERS, SYM1, SYM2 }

enum class Lang(val label: String, val ru: Boolean) {
    EN("English (US)", false),
    RU("Русский", true)
}

enum class Shift { OFF, ONCE, CAPS }

enum class EnterKind { ENTER, SEARCH, GO, SEND, NEXT, DONE }

class Key(
    val type: KeyType,
    val text: String = "",
    val width: Float = 0f,          // 0 = растягивается (пробел)
    val hint: String? = null,
    val numberRow: Boolean = false,
) {
    var left = 0f
    var top = 0f
    var right = 0f
    var bottom = 0f
    var hitL = 0f
    var hitT = 0f
    var hitR = 0f
    var hitB = 0f
    var pressed = false

    val isFn: Boolean
        get() = when (type) {
            KeyType.SHIFT, KeyType.BACKSPACE, KeyType.SYMBOLS,
            KeyType.LETTERS, KeyType.PAGE, KeyType.ACTION -> true
            else -> false
        }

    fun hit(x: Float, y: Float): Boolean = x >= hitL && x < hitR && y >= hitT && y < hitB
}

class Row(val keys: List<Key>, val gaps: List<Float>, val height: Float)

object Layouts {

    fun rows(page: Page, lang: Lang): List<Row> {
        val list = ArrayList<Row>()
        list.add(uniform("1234567890", M.KEY_W, M.GAP, M.NUM_H, numberRow = true))
        when (page) {
            Page.LETTERS -> list.addAll(letterRows(lang))
            Page.SYM1 -> list.addAll(sym1(lang))
            Page.SYM2 -> list.addAll(sym2(lang))
        }
        list.add(bottomRow(page, lang))
        return list
    }

    private fun uniform(
        chars: String, w: Float, gap: Float, h: Float,
        numberRow: Boolean = false, hints: Map<Char, String> = emptyMap(),
    ): Row {
        val keys = chars.map { Key(KeyType.CHAR, it.toString(), w, hints[it], numberRow) }
        return Row(keys, List(keys.size - 1) { gap }, h)
    }

    private fun fnRow(
        left: Key, chars: String, w: Float, gap: Float, edgeGap: Float, right: Key,
        hints: Map<Char, String> = emptyMap(),
    ): Row {
        val mids = chars.map { Key(KeyType.CHAR, it.toString(), w, hints[it]) }
        val keys = ArrayList<Key>()
        keys.add(left)
        keys.addAll(mids)
        keys.add(right)
        val gaps = ArrayList<Float>()
        gaps.add(edgeGap)
        repeat(mids.size - 1) { gaps.add(gap) }
        gaps.add(edgeGap)
        return Row(keys, gaps, M.ROW_H)
    }

    private fun letterRows(lang: Lang): List<Row> =
        if (!lang.ru) listOf(
            uniform("qwertyuiop", M.KEY_W, M.GAP, M.ROW_H),
            uniform("asdfghjkl", M.KEY_W, M.GAP, M.ROW_H),
            fnRow(
                Key(KeyType.SHIFT, "", M.FN3), "zxcvbnm", M.KEY_W, M.GAP, M.GAP_FN3,
                Key(KeyType.BACKSPACE, "", M.FN3),
            ),
        ) else listOf(
            uniform("йцукенгшщзх", M.KEY_W_RU, M.GAP_RU, M.ROW_H, hints = mapOf('е' to "ё")),
            uniform("фывапролджэ", M.KEY_W_RU, M.GAP_RU, M.ROW_H),
            fnRow(
                Key(KeyType.SHIFT, "", M.FN3_RU), "ячсмитьбю", M.KEY_W_RU, M.GAP_RU3, M.GAP_RU3,
                Key(KeyType.BACKSPACE, "", M.FN3_RU), hints = mapOf('ь' to "ъ"),
            ),
        )

    private fun sym1(lang: Lang): List<Row> {
        val r2 = "!@#$%^&*()".let { if (lang.ru) it.replace('$', '₽') else it }
        return listOf(
            uniform("+×÷=/_<>[]", M.KEY_W, M.GAP, M.ROW_H),
            uniform(r2, M.KEY_W, M.GAP, M.ROW_H),
            fnRow(
                Key(KeyType.PAGE, "1/2", M.FN3), "-'\":;,?", M.KEY_W, M.GAP, M.GAP_FN3,
                Key(KeyType.BACKSPACE, "", M.FN3),
            ),
        )
    }

    private fun sym2(lang: Lang): List<Row> {
        val r1 = "`~\\|{}€£¥₩".let { if (lang.ru) it.replace('₩', '$') else it }
        return listOf(
            uniform(r1, M.KEY_W, M.GAP, M.ROW_H),
            uniform("°•○●□■♤♡◇♧", M.KEY_W, M.GAP, M.ROW_H),
            fnRow(
                Key(KeyType.PAGE, "2/2", M.FN3), "☆▪¤《》¡¿", M.KEY_W, M.GAP, M.GAP_FN3,
                Key(KeyType.BACKSPACE, "", M.FN3),
            ),
        )
    }

    private fun bottomRow(page: Page, lang: Lang): Row {
        val left = if (page == Page.LETTERS) Key(KeyType.SYMBOLS, "!#1", M.FN_BOT)
        else Key(KeyType.LETTERS, if (lang.ru) "АБВ" else "ABC", M.FN_BOT)
        val keys = listOf(
            left,
            Key(KeyType.COMMA, ",", M.SMALL),
            Key(KeyType.GLOBE, "", M.SMALL),
            Key(KeyType.SPACE, "", 0f),
            Key(KeyType.PERIOD, ".", M.SMALL),
            Key(KeyType.ACTION, "", M.FN_BOT),
        )
        return Row(keys, List(5) { M.GAP_BOT }, M.ROW_H)
    }
}
