package dev.neverboard

import android.animation.ValueAnimator
import android.content.Context
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.CornerPathEffect
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.util.SparseArray
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.min

interface KeyboardHost {
    fun onText(text: String)
    fun onBackspace()
    fun onAction()
    fun onSpace()
    fun onCursor(dir: Int)
    fun onGlobeLongPress()
    fun onLangChanged(lang: Lang)
    fun onToolbar(item: Int)
    fun onHide()
}

/** Вся клавиатура рисуется на Canvas: быстро и полный контроль над внешним видом. */
class KeyboardView(context: Context, private val host: KeyboardHost) : View(context) {

    var page: Page = Page.LETTERS
        private set
    var lang: Lang = Lang.EN
        private set
    var shift: Shift = Shift.OFF
        private set
    private var enter: EnterKind = EnterKind.ENTER

    private var rows: List<Row> = Layouts.rows(page, lang)
    private var rowsBottom = 0f

    private var sx = 1f
    private var sy = 1f
    private var st = 1f

    private val handler = Handler(Looper.getMainLooper())
    private val ptrs = SparseArray<Ptr>()
    private var tbPressed = -1
    private var lastShiftTap = 0L
    private var ns = 0f                       // 0..1 — "Never Settle" вместо названия языка
    private var nsAnim: ValueAnimator? = null

    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val shadowP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val iconP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val textP = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val medium: Typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    private val tbX = floatArrayOf(95f, 285f, 475f, 1015f)

    private class Ptr(val key: Key?, val tb: Int, val chevron: Boolean, val downX: Float) {
        var longPressed = false
        var cursorMode = false
        var lastCursorX = downX
        var longRun: Runnable? = null
        var repeatRun: Runnable? = null
    }

    // ---------------------------------------------------------------- состояние

    fun showPage(p: Page) {
        if (p != page) {
            page = p
            rebuild()
        }
    }

    fun showLang(l: Lang) {
        if (l != lang) {
            lang = l
            rebuild()
        }
    }

    fun applyEnter(k: EnterKind) {
        if (k != enter) {
            enter = k
            invalidate()
        }
    }

    /** Автоматическая заглавная в начале предложения. Caps Lock не трогаем. */
    fun applyAutoShift(on: Boolean) {
        if (shift == Shift.CAPS) return
        val n = if (on) Shift.ONCE else Shift.OFF
        if (n != shift) {
            shift = n
            invalidate()
        }
    }

    fun resetTouch() {
        for (i in 0 until ptrs.size()) cancelRuns(ptrs.valueAt(i))
        ptrs.clear()
        for (r in rows) for (k in r.keys) k.pressed = false
        tbPressed = -1
        nsAnim?.cancel()
        ns = 0f
        invalidate()
    }

    private fun rebuild() {
        rows = Layouts.rows(page, lang)
        layoutKeys()
        invalidate()
    }

    private fun shiftTap() {
        val now = System.currentTimeMillis()
        shift = when {
            shift == Shift.CAPS -> Shift.OFF
            shift == Shift.ONCE && now - lastShiftTap < 350 -> Shift.CAPS
            shift == Shift.ONCE -> Shift.OFF
            else -> Shift.ONCE
        }
        lastShiftTap = now
        invalidate()
    }

    private fun toggleLang() {
        showLang(if (lang == Lang.EN) Lang.RU else Lang.EN)
        host.onLangChanged(lang)
    }

    private fun setNeverSettle(on: Boolean) {
        nsAnim?.cancel()
        val a = ValueAnimator.ofFloat(ns, if (on) 1f else 0f)
        a.duration = 140
        a.addUpdateListener {
            ns = it.animatedValue as Float
            invalidate()
        }
        nsAnim = a
        a.start()
    }

    // ---------------------------------------------------------------- размеры

    private fun computeScales(w: Int) {
        sx = w / M.BASE_W
        val land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        if (land) {
            val dm = resources.displayMetrics
            val short = min(dm.widthPixels, dm.heightPixels).toFloat()
            sy = short / M.BASE_W * 0.56f
            st = sy * 1.3f
        } else {
            sy = sx
            st = sx
        }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        computeScales(w)
        val h = (M.TOOLBAR_H + M.TOP_PAD + M.NUM_H + 4 * M.ROW_H + 4 * M.V_GAP + M.EXTRA) * sy
        setMeasuredDimension(w, h.toInt())
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        iconP.pathEffect = CornerPathEffect(7f * st)
        layoutKeys()
    }

    private fun layoutKeys() {
        val w = width.toFloat()
        if (w <= 0f) return
        val tbBottom = M.TOOLBAR_H * sy
        var y = (M.TOOLBAR_H + M.TOP_PAD) * sy
        for (row in rows) {
            val h = row.height * sy
            var fixed = 0f
            var flexCount = 0
            for (k in row.keys) {
                if (k.width == 0f) flexCount++ else fixed += k.width
            }
            var gapSum = 0f
            for (g in row.gaps) gapSum += g
            val flexW = if (flexCount > 0) (M.CONTENT - fixed - gapSum) / flexCount else 0f
            val total = fixed + gapSum + flexW * flexCount
            var x = (M.BASE_W - total) / 2f
            val last = row.keys.lastIndex
            row.keys.forEachIndexed { i, k ->
                val kw = if (k.width == 0f) flexW else k.width
                val gapL = if (i == 0) 0f else row.gaps[i - 1]
                val gapR = if (i == last) 0f else row.gaps[i]
                k.left = x * sx
                k.right = (x + kw) * sx
                k.top = y
                k.bottom = y + h
                k.hitL = if (i == 0) 0f else k.left - gapL * sx / 2f
                k.hitR = if (i == last) w else k.right + gapR * sx / 2f
                k.hitT = maxOf(tbBottom, y - M.V_GAP * sy / 2f)
                k.hitB = y + h + M.V_GAP * sy / 2f
                x += kw + gapR
            }
            rowsBottom = y + h
            y += h + M.V_GAP * sy
        }
    }

    // ---------------------------------------------------------------- рисование

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        c.drawColor(Colors.BG)
        fillP.color = Colors.TOOLBAR
        c.drawRect(0f, 0f, w, M.TOOLBAR_H * sy, fillP)
        drawToolbar(c)
        for (row in rows) for (k in row.keys) drawKey(c, k)
        iconP.color = Colors.INK
        iconP.strokeWidth = 4f * st
        Icons.chevronDown(c, 974.5f * sx, rowsBottom + 104f * sy, 24f * st, iconP)
    }

    private fun drawToolbar(c: Canvas) {
        val cy = M.TOOLBAR_H * sy / 2f
        val r = 48f * st
        for (i in 0..3) {
            val cx = tbX[i] * sx
            if (i < 3) {
                fillP.color = if (tbPressed == i) Colors.TB_PRESSED else Colors.TB_CIRCLE
                c.drawCircle(cx, cy, r, fillP)
            }
            iconP.color = Colors.INK
            iconP.strokeWidth = 4f * st
            when (i) {
                0 -> Icons.clipboard(c, cx, cy, 21f * st, iconP)
                1 -> Icons.smiley(c, cx, cy, 21f * st, iconP)
                2 -> Icons.gear(c, cx, cy, 21f * st, iconP)
                else -> {
                    fillP.color = Colors.INK
                    Icons.dots(c, cx, cy, 5f * st, fillP)
                }
            }
        }
    }

    private fun text(
        c: Canvas, s: String, x: Float, baseline: Float, size: Float, color: Int,
        tf: Typeface? = null, alpha: Int = 255, align: Paint.Align = Paint.Align.CENTER,
    ) {
        textP.textSize = size
        textP.color = color
        textP.alpha = alpha
        textP.typeface = tf ?: Typeface.DEFAULT
        textP.textAlign = align
        c.drawText(s, x, baseline, textP)
    }

    private fun drawKey(c: Canvas, k: Key) {
        val rad = M.RADIUS * min(sx, sy)
        shadowP.color = Color.argb(24, 0, 0, 0)
        c.drawRoundRect(k.left, k.top + 1.5f * sy, k.right, k.bottom + 1.5f * sy, rad, rad, shadowP)
        shadowP.color = Color.argb(8, 0, 0, 0)
        c.drawRoundRect(k.left, k.top + 3.2f * sy, k.right, k.bottom + 3.2f * sy, rad, rad, shadowP)

        fillP.color = when {
            k.isFn && k.pressed -> Colors.FN_PRESSED
            k.isFn -> Colors.FN
            k.pressed -> Colors.KEY_PRESSED
            else -> Colors.KEY
        }
        c.drawRoundRect(k.left, k.top, k.right, k.bottom, rad, rad, fillP)

        val cx = (k.left + k.right) / 2f
        val cy = (k.top + k.bottom) / 2f
        iconP.strokeWidth = 4.5f * st
        iconP.color = Colors.INK

        when (k.type) {
            KeyType.CHAR -> {
                val digit = k.numberRow
                val upper = !digit && page == Page.LETTERS && shift != Shift.OFF
                val label = if (upper) k.text.uppercase() else k.text
                val size = (if (digit) M.TXT_DIGIT else M.TXT_LETTER) * st
                val base = k.top + (if (digit) M.BASE_DIGIT else M.BASE_LETTER) * sy
                val color = if (digit && k.text == "1") Colors.RED else Colors.INK
                text(c, label, cx, base, size, color)
                val h = k.hint
                if (h != null) {
                    text(
                        c, h, k.right - 8f * sx, k.top + 32f * sy, M.TXT_HINT * st,
                        Colors.HINT, null, 255, Paint.Align.RIGHT,
                    )
                }
            }
            KeyType.COMMA, KeyType.PERIOD ->
                text(c, k.text, cx, k.top + M.BASE_LETTER * sy, M.TXT_LETTER * st, Colors.INK)
            KeyType.SHIFT -> {
                iconP.color = if (shift != Shift.OFF) Colors.RED else Colors.INK
                iconP.strokeWidth = (if (shift == Shift.CAPS) 9f else 4.5f) * st
                Icons.shift(c, cx, cy - 2f * sy, 25f * st, iconP)
            }
            KeyType.BACKSPACE -> Icons.backspace(c, cx, cy, 30f * st, iconP)
            KeyType.SYMBOLS, KeyType.LETTERS, KeyType.PAGE ->
                text(c, k.text, cx, cy + M.TXT_FN * st * 0.3555f, M.TXT_FN * st, Colors.INK)
            KeyType.GLOBE -> Icons.globe(c, cx, cy, 23f * st, iconP)
            KeyType.SPACE -> {
                val size = M.TXT_SPACE * st
                val base = cy + size * 0.3555f
                if (ns < 1f) text(c, lang.label, cx, base, size, Colors.INK, null, ((1f - ns) * 255).toInt())
                if (ns > 0f) text(c, "Never Settle", cx, base, size * 1.05f, Colors.RED, medium, (ns * 255).toInt())
            }
            KeyType.ACTION -> drawAction(c, cx, cy)
        }
    }

    private fun drawAction(c: Canvas, cx: Float, cy: Float) {
        when (enter) {
            EnterKind.ENTER -> Icons.enter(c, cx, cy, 28f * st, iconP)
            EnterKind.SEARCH -> {
                iconP.color = Colors.BLUE
                Icons.search(c, cx, cy, 28f * st, iconP)
            }
            else -> {
                val ru = lang.ru
                val label = when (enter) {
                    EnterKind.GO -> if (ru) "Перейти" else "Go"
                    EnterKind.SEND -> if (ru) "Отпр." else "Send"
                    EnterKind.NEXT -> if (ru) "Далее" else "Next"
                    else -> if (ru) "Готово" else "Done"
                }
                val size = M.TXT_FN * 0.75f * st
                text(c, label, cx, cy + size * 0.3555f, size, Colors.INK)
            }
        }
    }

    // ---------------------------------------------------------------- касания

    private fun tap() {
        performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
    }

    private fun keyAt(x: Float, y: Float): Key? {
        for (row in rows) for (k in row.keys) if (k.hit(x, y)) return k
        return null
    }

    private fun toolbarIndexAt(x: Float): Int {
        var best = -1
        var bd = Float.MAX_VALUE
        for (i in tbX.indices) {
            val d = abs(x - tbX[i] * sx)
            if (d < bd) {
                bd = d
                best = i
            }
        }
        return if (bd < 95f * sx) best else -1
    }

    private fun cancelRuns(p: Ptr) {
        p.longRun?.let { handler.removeCallbacks(it) }
        p.repeatRun?.let { handler.removeCallbacks(it) }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                down(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until e.pointerCount) move(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                val i = e.actionIndex
                up(e.getPointerId(i), e.getX(i), e.getY(i), false)
            }
            MotionEvent.ACTION_CANCEL -> {
                val ids = IntArray(ptrs.size()) { ptrs.keyAt(it) }
                for (id in ids) up(id, 0f, 0f, true)
            }
        }
        return true
    }

    private fun down(id: Int, x: Float, y: Float) {
        if (y < M.TOOLBAR_H * sy) {
            val i = toolbarIndexAt(x)
            ptrs.put(id, Ptr(null, i, false, x))
            if (i >= 0) {
                tbPressed = i
                tap()
                invalidate()
            }
            return
        }
        if (y > rowsBottom + 10f * sy && x > width * 0.7f) {
            ptrs.put(id, Ptr(null, -1, true, x))
            return
        }
        val k = keyAt(x, y) ?: return
        val p = Ptr(k, -1, false, x)
        ptrs.put(id, p)
        k.pressed = true
        tap()
        when (k.type) {
            KeyType.BACKSPACE -> {
                host.onBackspace()
                val r = object : Runnable {
                    override fun run() {
                        host.onBackspace()
                        handler.postDelayed(this, 45)
                    }
                }
                p.repeatRun = r
                handler.postDelayed(r, 380)
            }
            KeyType.SPACE -> {
                val r = Runnable {
                    p.longPressed = true
                    setNeverSettle(true)
                    performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                }
                p.longRun = r
                handler.postDelayed(r, 350)
            }
            KeyType.GLOBE -> {
                val r = Runnable {
                    p.longPressed = true
                    host.onGlobeLongPress()
                }
                p.longRun = r
                handler.postDelayed(r, 450)
            }
            else -> {}
        }
        invalidate()
    }

    private fun move(id: Int, x: Float, y: Float) {
        val p = ptrs.get(id) ?: return
        val k = p.key ?: return
        if (k.type != KeyType.SPACE) return
        if (!p.cursorMode) {
            if (abs(x - p.downX) > 24f * sx) {
                p.cursorMode = true
                p.lastCursorX = x
                p.longRun?.let { handler.removeCallbacks(it) }
            }
            return
        }
        val step = 46f * sx
        while (x - p.lastCursorX >= step) {
            p.lastCursorX += step
            host.onCursor(1)
            performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
        }
        while (p.lastCursorX - x >= step) {
            p.lastCursorX -= step
            host.onCursor(-1)
            performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
        }
    }

    private fun up(id: Int, x: Float, y: Float, cancel: Boolean) {
        val p = ptrs.get(id) ?: return
        ptrs.remove(id)
        cancelRuns(p)

        if (p.chevron) {
            if (!cancel && y > rowsBottom && x > width * 0.7f) host.onHide()
            return
        }
        val k = p.key
        if (k == null) {
            tbPressed = -1
            invalidate()
            if (!cancel && p.tb >= 0 && y < M.TOOLBAR_H * sy && toolbarIndexAt(x) == p.tb) {
                host.onToolbar(p.tb)
            }
            return
        }

        k.pressed = false
        if (k.type == KeyType.SPACE && p.longPressed) setNeverSettle(false)
        invalidate()
        if (cancel) return

        when (k.type) {
            KeyType.BACKSPACE -> {}
            KeyType.SPACE -> if (!p.cursorMode && !p.longPressed && k.hit(x, y)) fire(k)
            KeyType.GLOBE -> if (!p.longPressed && k.hit(x, y)) fire(k)
            KeyType.CHAR -> {
                val target = if (k.hit(x, y)) k else keyAt(x, y)?.takeIf { it.type == KeyType.CHAR }
                if (target != null) fire(target)
            }
            else -> if (k.hit(x, y)) fire(k)
        }
    }

    private fun fire(k: Key) {
        when (k.type) {
            KeyType.CHAR -> {
                val upper = !k.numberRow && page == Page.LETTERS && shift != Shift.OFF
                host.onText(if (upper) k.text.uppercase() else k.text)
                if (upper && shift == Shift.ONCE) {
                    shift = Shift.OFF
                    invalidate()
                }
            }
            KeyType.COMMA, KeyType.PERIOD -> host.onText(k.text)
            KeyType.SHIFT -> shiftTap()
            KeyType.SYMBOLS -> showPage(Page.SYM1)
            KeyType.LETTERS -> showPage(Page.LETTERS)
            KeyType.PAGE -> showPage(if (page == Page.SYM1) Page.SYM2 else Page.SYM1)
            KeyType.GLOBE -> toggleLang()
            KeyType.ACTION -> host.onAction()
            KeyType.SPACE -> host.onSpace()
            KeyType.BACKSPACE -> {}
        }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        resetTouch()
    }
}
