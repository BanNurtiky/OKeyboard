package dev.neverboard

/**
 * Размеры сняты со скриншотов Samsung Keyboard (1080 px в ширину).
 * Все значения в "базовых пикселях" при ширине 1080, дальше масштабируются.
 */
object M {
    const val BASE_W = 1080f
    const val CONTENT = 1032f      // ширина области клавиш (поля по 24)

    const val TOOLBAR_H = 132f
    const val TOP_PAD = 22f
    const val NUM_H = 96f
    const val ROW_H = 116f
    const val V_GAP = 34f
    const val EXTRA = 125f         // зона под клавишами (шеврон "скрыть")
    const val RADIUS = 16f

    const val KEY_W = 87f
    const val KEY_W_RU = 79f
    const val GAP = 18f
    const val GAP_RU = 16.3f
    const val GAP_RU3 = 15.5f
    const val FN3 = 123f
    const val FN3_RU = 83f
    const val GAP_FN3 = 34f
    const val FN_BOT = 139f
    const val SMALL = 86f
    const val GAP_BOT = 19f

    const val TXT_LETTER = 70f
    const val TXT_DIGIT = 62f
    const val TXT_FN = 49f
    const val TXT_HINT = 26f
    const val TXT_SPACE = 37f
    const val BASE_LETTER = 83f    // базовая линия от верха клавиши (буквы)
    const val BASE_DIGIT = 71f     // базовая линия цифр
}

object Colors {
    val BG = 0xFFE4E4E6.toInt()
    val TOOLBAR = 0xFFF6F6F8.toInt()
    val KEY = 0xFFFCFCFE.toInt()
    val FN = 0xFFC9C9CB.toInt()
    val KEY_PRESSED = 0xFFD5D5DA.toInt()
    val FN_PRESSED = 0xFFB0B0B4.toInt()
    val TB_CIRCLE = 0xFFE9E9EB.toInt()
    val TB_PRESSED = 0xFFD6D6DA.toInt()
    val INK = 0xFF242426.toInt()
    val HINT = 0xFF6E6E73.toInt()
    val RED = 0xFFF50514.toInt()       // красный OnePlus
    val BLUE = 0xFF3C58D8.toInt()
}
