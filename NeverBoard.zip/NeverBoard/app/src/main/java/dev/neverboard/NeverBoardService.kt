package dev.neverboard

import android.content.Intent
import android.inputmethodservice.InputMethodService
import android.text.InputType
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Toast

class NeverBoardService : InputMethodService(), KeyboardHost {

    private var kb: KeyboardView? = null
    private val prefs by lazy { getSharedPreferences("neverboard", MODE_PRIVATE) }

    override fun onCreateInputView(): View {
        val v = KeyboardView(this, this)
        v.showLang(if (prefs.getString("lang", "EN") == "RU") Lang.RU else Lang.EN)
        kb = v
        return v
    }

    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onStartInputView(info: EditorInfo, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        val v = kb ?: return
        runCatching { window?.window?.navigationBarColor = Colors.BG }
        v.resetTouch()
        if (!restarting) {
            val cls = info.inputType and InputType.TYPE_MASK_CLASS
            val numeric = cls == InputType.TYPE_CLASS_NUMBER ||
                cls == InputType.TYPE_CLASS_PHONE ||
                cls == InputType.TYPE_CLASS_DATETIME
            v.showPage(if (numeric) Page.SYM1 else Page.LETTERS)
        }
        v.applyEnter(enterKindFor(info))
        updateAutoCaps()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        kb?.resetTouch()
    }

    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int, newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int,
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        updateAutoCaps()
    }

    private fun updateAutoCaps() {
        val v = kb ?: return
        val info = currentInputEditorInfo ?: return
        val ic = currentInputConnection ?: return
        if ((info.inputType and InputType.TYPE_MASK_CLASS) != InputType.TYPE_CLASS_TEXT) {
            v.applyAutoShift(false)
            return
        }
        v.applyAutoShift(ic.getCursorCapsMode(info.inputType) != 0)
    }

    private fun enterKindFor(info: EditorInfo): EnterKind {
        if ((info.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0) return EnterKind.ENTER
        if ((info.inputType and InputType.TYPE_TEXT_FLAG_MULTI_LINE) != 0) return EnterKind.ENTER
        return when (info.imeOptions and EditorInfo.IME_MASK_ACTION) {
            EditorInfo.IME_ACTION_SEARCH -> EnterKind.SEARCH
            EditorInfo.IME_ACTION_GO -> EnterKind.GO
            EditorInfo.IME_ACTION_SEND -> EnterKind.SEND
            EditorInfo.IME_ACTION_NEXT -> EnterKind.NEXT
            EditorInfo.IME_ACTION_DONE -> EnterKind.DONE
            else -> EnterKind.ENTER
        }
    }

    // ------------------------------------------------------------ KeyboardHost

    override fun onText(text: String) {
        currentInputConnection?.commitText(text, 1)
    }

    override fun onSpace() {
        currentInputConnection?.commitText(" ", 1)
    }

    override fun onBackspace() {
        val ic = currentInputConnection ?: return
        val sel = ic.getSelectedText(0)
        if (!sel.isNullOrEmpty()) ic.commitText("", 1)
        else sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
    }

    override fun onAction() {
        val ic = currentInputConnection ?: return
        val info = currentInputEditorInfo ?: return
        val multi = (info.inputType and InputType.TYPE_TEXT_FLAG_MULTI_LINE) != 0
        val noAction = (info.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        val action = info.imeOptions and EditorInfo.IME_MASK_ACTION
        if (multi || noAction || action == EditorInfo.IME_ACTION_NONE ||
            action == EditorInfo.IME_ACTION_UNSPECIFIED
        ) {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        } else {
            ic.performEditorAction(action)
        }
    }

    override fun onCursor(dir: Int) {
        sendDownUpKeyEvents(if (dir < 0) KeyEvent.KEYCODE_DPAD_LEFT else KeyEvent.KEYCODE_DPAD_RIGHT)
    }

    override fun onGlobeLongPress() {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
    }

    override fun onLangChanged(lang: Lang) {
        prefs.edit().putString("lang", lang.name).apply()
    }

    override fun onToolbar(item: Int) {
        when (item) {
            2 -> startActivity(
                Intent(this, SettingsActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            0 -> toast("Буфер обмена будет на этапе 2")
            1 -> toast("Эмодзи добавим позже")
            else -> toast("Меню появится позже")
        }
    }

    override fun onHide() {
        requestHideSelf(0)
    }

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    }
}
