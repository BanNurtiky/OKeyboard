package dev.neverboard

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Экран-помощник: включить клавиатуру, выбрать её и проверить набор. */
class SettingsActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(32), dp(20), dp(20))
        }

        root.addView(TextView(this).apply {
            text = "NeverBoard"
            textSize = 28f
        })
        root.addView(TextView(this).apply {
            text = "Клавиатура в стиле Samsung с характером OnePlus. Этап 1."
            textSize = 15f
            setPadding(0, dp(4), 0, dp(20))
        })

        root.addView(Button(this).apply {
            text = "1. Включить клавиатуру"
            setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        })
        root.addView(Button(this).apply {
            text = "2. Выбрать NeverBoard"
            setOnClickListener {
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
            }
        })
        root.addView(EditText(this).apply {
            hint = "3. Нажми сюда и проверь набор"
            minLines = 3
            gravity = android.view.Gravity.TOP
            setPadding(0, dp(24), 0, 0)
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }
}
