package dev.neverboard

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import kotlin.math.cos
import kotlin.math.sin

/** Простые иконки, нарисованные контуром. Paint должен быть в режиме STROKE. */
object Icons {
    private val path = Path()
    private val rect = RectF()

    fun shift(c: Canvas, cx: Float, cy: Float, s: Float, p: Paint) {
        path.reset()
        path.moveTo(cx, cy - s)
        path.lineTo(cx + s, cy + 0.1f * s)
        path.lineTo(cx + 0.5f * s, cy + 0.1f * s)
        path.lineTo(cx + 0.5f * s, cy + 0.95f * s)
        path.lineTo(cx - 0.5f * s, cy + 0.95f * s)
        path.lineTo(cx - 0.5f * s, cy + 0.1f * s)
        path.lineTo(cx - s, cy + 0.1f * s)
        path.close()
        c.drawPath(path, p)
    }

    fun backspace(c: Canvas, cx: Float, cy: Float, s: Float, p: Paint) {
        path.reset()
        path.moveTo(cx - s, cy)
        path.lineTo(cx - 0.35f * s, cy - 0.78f * s)
        path.lineTo(cx + s, cy - 0.78f * s)
        path.lineTo(cx + s, cy + 0.78f * s)
        path.lineTo(cx - 0.35f * s, cy + 0.78f * s)
        path.close()
        c.drawPath(path, p)
        c.drawLine(cx + 0.1f * s, cy - 0.28f * s, cx + 0.65f * s, cy + 0.28f * s, p)
        c.drawLine(cx + 0.65f * s, cy - 0.28f * s, cx + 0.1f * s, cy + 0.28f * s, p)
    }

    fun globe(c: Canvas, cx: Float, cy: Float, s: Float, p: Paint) {
        c.drawCircle(cx, cy, s, p)
        c.drawLine(cx - s, cy, cx + s, cy, p)
        rect.set(cx - 0.45f * s, cy - s, cx + 0.45f * s, cy + s)
        c.drawOval(rect, p)
    }

    fun enter(c: Canvas, cx: Float, cy: Float, s: Float, p: Paint) {
        path.reset()
        path.moveTo(cx + 0.85f * s, cy - 0.7f * s)
        path.lineTo(cx + 0.85f * s, cy + 0.15f * s)
        path.lineTo(cx - 0.8f * s, cy + 0.15f * s)
        path.moveTo(cx - 0.25f * s, cy - 0.4f * s)
        path.lineTo(cx - 0.8f * s, cy + 0.15f * s)
        path.lineTo(cx - 0.25f * s, cy + 0.7f * s)
        c.drawPath(path, p)
    }

    fun search(c: Canvas, cx: Float, cy: Float, s: Float, p: Paint) {
        c.drawCircle(cx - 0.2f * s, cy - 0.2f * s, 0.65f * s, p)
        c.drawLine(cx + 0.27f * s, cy + 0.27f * s, cx + 0.95f * s, cy + 0.95f * s, p)
    }

    fun chevronDown(c: Canvas, cx: Float, cy: Float, s: Float, p: Paint) {
        path.reset()
        path.moveTo(cx - s, cy - 0.45f * s)
        path.lineTo(cx, cy + 0.45f * s)
        path.lineTo(cx + s, cy - 0.45f * s)
        c.drawPath(path, p)
    }

    fun clipboard(c: Canvas, cx: Float, cy: Float, s: Float, p: Paint) {
        rect.set(cx - 0.62f * s, cy - 0.75f * s, cx + 0.62f * s, cy + 0.9f * s)
        c.drawRoundRect(rect, 0.2f * s, 0.2f * s, p)
        rect.set(cx - 0.32f * s, cy - 0.98f * s, cx + 0.32f * s, cy - 0.5f * s)
        c.drawRoundRect(rect, 0.15f * s, 0.15f * s, p)
    }

    fun smiley(c: Canvas, cx: Float, cy: Float, s: Float, p: Paint) {
        c.drawCircle(cx, cy, s, p)
        val old = p.style
        p.style = Paint.Style.FILL
        c.drawCircle(cx - 0.36f * s, cy - 0.25f * s, 0.1f * s, p)
        c.drawCircle(cx + 0.36f * s, cy - 0.25f * s, 0.1f * s, p)
        p.style = old
        rect.set(cx - 0.55f * s, cy - 0.45f * s, cx + 0.55f * s, cy + 0.6f * s)
        c.drawArc(rect, 25f, 130f, false, p)
    }

    fun gear(c: Canvas, cx: Float, cy: Float, s: Float, p: Paint) {
        c.drawCircle(cx, cy, 0.68f * s, p)
        c.drawCircle(cx, cy, 0.28f * s, p)
        for (i in 0 until 8) {
            val a = Math.toRadians(i * 45.0)
            val x1 = cx + (0.68f * s * cos(a)).toFloat()
            val y1 = cy + (0.68f * s * sin(a)).toFloat()
            val x2 = cx + (1.0f * s * cos(a)).toFloat()
            val y2 = cy + (1.0f * s * sin(a)).toFloat()
            c.drawLine(x1, y1, x2, y2, p)
        }
    }

    fun dots(c: Canvas, cx: Float, cy: Float, r: Float, p: Paint) {
        val old = p.style
        p.style = Paint.Style.FILL
        c.drawCircle(cx - 4f * r, cy, r, p)
        c.drawCircle(cx, cy, r, p)
        c.drawCircle(cx + 4f * r, cy, r, p)
        p.style = old
    }
}
